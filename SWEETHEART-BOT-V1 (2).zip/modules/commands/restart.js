const fs = require('fs');

module.exports.config = {
  name: "restart",
  version: "1.0.0",
  hasPermssion: 2,
  credits: "KOJA XD",
  description: "restart",
  commandCategory: "Admin",
  usages: "",
  cooldowns: 2,
  dependencies: {
    "fs-extra": ""
  }
};

module.exports.run = async function({ api, event, args, Threads, Users, Currencies, models, botname }) {
  const process = require("process");
  const { threadID, messageID } = event;
  api.sendMessage(`restarting the whole system, please be patient.`, threadID, ()=> process.exit(1));
}
