module.exports.config = {
    name: "enjoy",
    version: "1.0.2",
   hasPermission: 0,
    credits: "KOJA-PROJECT",
    description: "Tag 10 times continuously",
    commandCategory: "Group",
    usages: "Tharakpan",
    cooldowns: 5,
    dependencies: { }
}
 
module.exports.run = async function({ api, args, Users, event}) {
const { threadID, messageID, senderID, mentions } = event;
var mention = Object.keys(mentions)[0];
setTimeout(() =>
api.sendMessage({
   body:"Oye BaBe CoMe HeRe 😗" + mentions[mention].replace("@", "") ,
   mentions: [{
    tag: mentions[mention].replace("@", ""),
    id: mention
   }]
  }, threadID, messageID), 3000)
setTimeout(() =>
api.sendMessage("Main Uh K0o BtaTai TraRak Kya HoTi  🥵🫂", threadID), 6000)
 
setTimeout(() =>
api.sendMessage("ChaLo Ab Main STarT kRrTi Hun ", threadID), 9000)

var a = Math.floor(Math.random() * 7);
if ( a==0 ) {
setTimeout(() =>
api.sendMessage({
   body:"Yeh DeKho BaBe Umumuaahhhhh 😘 ❤️" + mentions[mention].replace("@", "") ,
   mentions: [{
    tag: mentions[mention].replace("@", ""),
    id: mention
   }]
  }, threadID), 15000)
setTimeout(() =>
api.sendMessage({
   body:"LiPPi PRr Umumuaahhhhh  😘 💋" + mentions[mention].replace("@", "") ,
   mentions: [{
    tag: mentions[mention].replace("@", ""),
    id: mention
   }]
  }, threadID), 20000)
setTimeout(() =>
api.sendMessage({
   body:"JaNu Z0or Sy Hug 🤗🫂" + mentions[mention].replace("@", "") ,
   mentions: [{
    tag: mentions[mention].replace("@", ""),
    id: mention
   }]
  }, threadID), 25000)
setTimeout(() =>
api.sendMessage({
   body: "Neck Prr BiTe Umumuaahhhhh 😘🙈🙈🙈"+ mentions[mention].replace("@", "") ,
   mentions: [{
    tag: mentions[mention].replace("@", ""),
    id: mention
   }]
  }, threadID), 30000)
setTimeout(() =>
api.sendMessage({
   body: "Lips 👄 Prr BiTe Aah umumuaahhhhh 😘💋"+ mentions[mention].replace("@", "") ,
   mentions: [{
    tag: mentions[mention].replace("@", ""),
    id: mention
   }]
  }, threadID), 35000)
setTimeout(() =>
api.sendMessage({
   body: "Umumuaahhhhh Umumuaahhhhh 😘"+ mentions[mention].replace("@", "") ,
   mentions: [{
    tag: mentions[mention].replace("@", ""),
    id: mention
   }]
  }, threadID), 40000)
setTimeout(() =>
api.sendMessage({
   body:"JaNu KYa Huwa Hosh kRro Abhi T0o Start KiYa 😘😘😘" + mentions[mention].replace("@", "") ,
   mentions: [{
    tag: mentions[mention].replace("@", ""),
    id: mention
   }]
  }, threadID), 45000)
setTimeout(() =>
api.sendMessage({
   body: " JaNu SuNo Naww Ab Kaha Bag Rhy 🤪☹️🙈"+ mentions[mention].replace("@", "") ,
   mentions: [{
    tag: mentions[mention].replace("@", ""),
    id: mention
   }]
  }, threadID), 50000)
setTimeout(() =>
api.sendMessage({
   body: "Tum T0o Meko Pyal kRty Na 💋😘"+ mentions[mention].replace("@", "") ,
   mentions: [{
    tag: mentions[mention].replace("@", ""),
    id: mention
   }]
  }, threadID), 55000)
setTimeout(() =>
api.sendMessage({
   body:"SHarMao MaT Blo Ilu Ilu 😘🤪🙉" + mentions[mention].replace("@", "") ,
   mentions: [{
    tag: mentions[mention].replace("@", ""),
    id: mention
   }]
  }, threadID), 60000)
}
setTimeout(() =>
api.sendMessage({
   body:"Hawn T0o JaNu ThaKi Kaha The Ham 🥵 " + mentions[mention].replace("@", "") ,
   mentions: [{
    tag: mentions[mention].replace("@", ""),
    id: mention
   }]
  }, threadID), 65000)
  if (a==1) {
setTimeout(() =>
api.sendMessage({
   body:"Hawn JaNu 1 PaPpi Is GaL Pr 1 PaPpi Is Gal Prr umumuaahhhhh umumuaahhhhh 😘😘 " + mentions[mention].replace("@", "") ,
   mentions: [{
    tag: mentions[mention].replace("@", ""),
    id: mention
   }]
  }, threadID), 10000)
setTimeout(() =>
api.sendMessage({
   body:"JaNu ShaRam Aa Rhi KYa 🤪 " + mentions[mention].replace("@", "") ,
   mentions: [{
    tag: mentions[mention].replace("@", ""),
    id: mention
   }]
  }, threadID), 15000)
setTimeout(() =>
api.sendMessage({
   body: "Yeh L0o LiPpi Kiss umumuaahhhhhhhh 💋😘"+ mentions[mention].replace("@", "") ,
   mentions: [{
    tag: mentions[mention].replace("@", ""),
    id: mention
   }]
  }, threadID), 20000)
setTimeout(() =>
api.sendMessage({
   body: " HaYe JaNu Ab Lag Rha Uh Ny Mri Schi Me Jan Le LeNi JaNu 🥵"+ mentions[mention].replace("@", "") ,
   mentions: [{
    tag: mentions[mention].replace("@", ""),
    id: mention
   }]
  }, threadID), 25000)
setTimeout(() =>
api.sendMessage({
   body: "👅 "+ mentions[mention].replace("@", "") ,
   mentions: [{
    tag: mentions[mention].replace("@", ""),
    id: mention
   }]
  }, threadID), 30000)
setTimeout(() =>
api.sendMessage({
   body:"JaNu KYa Soch Rhy MeKo Sb Smjh Aa Rha 🙈🙉🙊" + mentions[mention].replace("@", "") ,
   mentions: [{
    tag: mentions[mention].replace("@", ""),
    id: mention
   }]
  }, threadID), 35000)
setTimeout(() =>
api.sendMessage({
   body: "😘💋😘💋"+ mentions[mention].replace("@", "") ,
   mentions: [{
    tag: mentions[mention].replace("@", ""),
    id: mention
   }]
  }, threadID), 40000)
setTimeout(() =>
api.sendMessage({
   body: "JaNuuuu"+ mentions[mention].replace("@", "") ,
   mentions: [{
    tag: mentions[mention].replace("@", ""),
    id: mention
   }]
  }, threadID), 45000)
setTimeout(() =>
api.sendMessage({
   body:"Blo Na Sb Kyun SharMa Rhy 🤣" + mentions[mention].replace("@", "") ,
   mentions: [{
    tag: mentions[mention].replace("@", ""),
    id: mention
   }]
  }, threadID), 50000)
}
if (a==2) {
setTimeout(() =>
api.sendMessage({
   body:"Tharaki JaNu 😜😜😜" + mentions[mention].replace("@", "") ,
   mentions: [{
    tag: mentions[mention].replace("@", ""),
    id: mention
   }]
  }, threadID), 10000)
setTimeout(() =>
api.sendMessage({
   body:"JaNu Akaly Me Ana Khushbu LaGa KRr 😜" + mentions[mention].replace("@", "") ,
   mentions: [{
    tag: mentions[mention].replace("@", ""),
    id: mention
   }]
  }, threadID), 15000)
setTimeout(() =>
api.sendMessage({
   body:"Umumuaahhhhh 😘" + mentions[mention].replace("@", "") ,
   mentions: [{
    tag: mentions[mention].replace("@", ""),
    id: mention
   }]
  }, threadID), 20000)
setTimeout(() =>
api.sendMessage({
   body: "JaNu ThanDy H0o Gye 🥺"+ mentions[mention].replace("@", "") ,
   mentions: [{
    tag: mentions[mention].replace("@", ""),
    id: mention
   }]
  }, threadID), 25000)
setTimeout(() =>
api.sendMessage({
   body: "🤭 "+ mentions[mention].replace("@", "") ,
   mentions: [{
    tag: mentions[mention].replace("@", ""),
    id: mention
   }]
  }, threadID), 30000)
setTimeout(() =>
api.sendMessage({
   body: "😜"+ mentions[mention].replace("@", "") ,
   mentions: [{
    tag: mentions[mention].replace("@", ""),
    id: mention
   }]
  }, threadID), 35000)
setTimeout(() =>
api.sendMessage({
   body:"😝" + mentions[mention].replace("@", "") ,
   mentions: [{
    tag: mentions[mention].replace("@", ""),
    id: mention
   }]
  }, threadID), 40000)
setTimeout(() =>
api.sendMessage({
   body: "🤪 "+ mentions[mention].replace("@", "") ,
   mentions: [{
    tag: mentions[mention].replace("@", ""),
    id: mention
   }]
  }, threadID), 45000)
setTimeout(() =>
api.sendMessage({
   body: "😋 "+ mentions[mention].replace("@", "") ,
   mentions: [{
    tag: mentions[mention].replace("@", ""),
    id: mention
   }]
  }, threadID), 50000)
setTimeout(() =>
api.sendMessage({
   body:"🤤" + mentions[mention].replace("@", "") ,
   mentions: [{
    tag: mentions[mention].replace("@", ""),
    id: mention
   }]
  }, threadID), 60000)
}
if (a==3) {
setTimeout(() =>
api.sendMessage({
   body:"🤫" + mentions[mention].replace("@", "") ,
   mentions: [{
    tag: mentions[mention].replace("@", ""),
    id: mention
   }]
  }, threadID), 10000)
setTimeout(() =>
api.sendMessage({
   body:"🤨" + mentions[mention].replace("@", "") ,
   mentions: [{
    tag: mentions[mention].replace("@", ""),
    id: mention
   }]
  }, threadID), 15000)
setTimeout(() =>
api.sendMessage({
   body:"🤒" + mentions[mention].replace("@", "") ,
   mentions: [{
    tag: mentions[mention].replace("@", ""),
    id: mention
   }]
  }, threadID), 20000)
setTimeout(() =>
api.sendMessage({
   body: "JaNuuuu"+ mentions[mention].replace("@", "") ,
   mentions: [{
    tag: mentions[mention].replace("@", ""),
    id: mention
   }]
  }, threadID), 25000)
setTimeout(() =>
api.sendMessage({
   body: "😝😝😝 "+ mentions[mention].replace("@", "") ,
   mentions: [{
    tag: mentions[mention].replace("@", ""),
    id: mention
   }]
  }, threadID), 30000)
setTimeout(() =>
api.sendMessage({
   body: "🤞😎"+ mentions[mention].replace("@", "") ,
   mentions: [{
    tag: mentions[mention].replace("@", ""),
    id: mention
   }]
  }, threadID), 35000)
setTimeout(() =>
api.sendMessage({
   body:"😂😂😂" + mentions[mention].replace("@", "") ,
   mentions: [{
    tag: mentions[mention].replace("@", ""),
    id: mention
   }]
  }, threadID), 40000)
setTimeout(() =>
api.sendMessage({
   body: "🐒 "+ mentions[mention].replace("@", "") ,
   mentions: [{
    tag: mentions[mention].replace("@", ""),
    id: mention
   }]
  }, threadID), 45000)
setTimeout(() =>
api.sendMessage({
   body: "🤭🤭🤭 "+ mentions[mention].replace("@", "") ,
   mentions: [{
    tag: mentions[mention].replace("@", ""),
    id: mention
   }]
  }, threadID), 50000)
setTimeout(() =>
api.sendMessage({
   body:"Main Nhi RukNa JaNu " + mentions[mention].replace("@", "") ,
   mentions: [{
    tag: mentions[mention].replace("@", ""),
    id: mention
   }]
  }, threadID), 60000)
}
if (a==4) {
setTimeout(() =>
api.sendMessage({
   body:"😋" + mentions[mention].replace("@", "") ,
   mentions: [{
    tag: mentions[mention].replace("@", ""),
    id: mention
   }]
  }, threadID), 10000)
setTimeout(() =>
api.sendMessage({
   body:"JaMu MeKo Uh ITny Axhy LagTy Jse PaNi K0o AGG LagTi Hai 🤣🙊😂" +
 entionss[mention].replace("@", "") ,
   mentions: [{
    tag: mentions[mention].replace("@", ""),
    id: mention
   }]
  }, threadID), 15000)
setTimeout(() =>
api.sendMessage({
   body: "JaMu Umumuaahhhhh 🥰Blo Nawww ☹️ " + mentions[mention].replace("@", "") ,
   mentions: [{
    tag: mentions[mention].replace("@", ""),
    id: mention
   }]
  }, threadID), 20000)
setTimeout(() =>
api.sendMessage({
   body: "JaNuuuuu "+ mentions[mention].replace("@", "") ,
   mentions: [{
    tag: mentions[mention].replace("@", ""),
    id: mention
   }]
  }, threadID), 25000)
setTimeout(() =>
api.sendMessage({
   body: "Main Jaun KYa  ☹️☹️☹️ "+ mentions[mention].replace("@", "") ,
   mentions: [{
    tag: mentions[mention].replace("@", ""),
    id: mention
   }]
  }, threadID), 30000)
setTimeout(() =>
api.sendMessage({
   body: "i Really Ilu 🤏🏻 Sa ☹️ "+ mentions[mention].replace("@", "") ,
   mentions: [{
    tag: mentions[mention].replace("@", ""),
    id: mention
   }]
  }, threadID), 35000)
setTimeout(() =>
api.sendMessage({
   body: "0o TharKi JaNu  😂. " + mentions[mention].replace("@", "") ,
   mentions: [{
    tag: mentions[mention].replace("@", ""),
    id: mention
   }]
  }, threadID), 40000)
setTimeout(() =>
api.sendMessage({
   body: "Axha ShoLy Naw☹️☹️☹️ "+ mentions[mention].replace("@", "") ,
   mentions: [{
    tag: mentions[mention].replace("@", ""),
    id: mention
   }]
  }, threadID), 45000)
setTimeout(() =>
api.sendMessage({
   body: "DaKho KiTna Pyal kRti Hu 😘 "+ mentions[mention].replace("@", "") ,
   mentions: [{
    tag: mentions[mention].replace("@", ""),
    id: mention
   }]
  }, threadID), 50000)
setTimeout(() =>
api.sendMessage({
   body:"🤭" + mentions[mention].replace("@", "") ,
   mentions: [{
    tag: mentions[mention].replace("@", ""),
    id: mention
   }]
  }, threadID), 60000)
}
if (a==5){
setTimeout(() =>
api.sendMessage({
   body:"Ilu 🙉" + mentions[mention].replace("@", "") ,
   mentions: [{
    tag: mentions[mention].replace("@", ""),
    id: mention
   }]
  }, threadID), 10000)
setTimeout(() =>
api.sendMessage({
   body:"JaNu Iluuu🙈" + mentions[mention].replace("@", "") ,
   mentions: [{
    tag: mentions[mention].replace("@", ""),
    id: mention
   }]
  }, threadID), 15000)
setTimeout(() =>
api.sendMessage({
   body:"Umumuaahhhhh 💋" + mentions[mention].replace("@", "") ,
   mentions: [{
    tag: mentions[mention].replace("@", ""),
    id: mention
   }]
  }, threadID), 20000)
setTimeout(() =>
api.sendMessage({
   body: "Uuuuuuummmmmaaaaahhh JaNuu 😘😘 "+ mentions[mention].replace("@", "") ,
   mentions: [{
    tag: mentions[mention].replace("@", ""),
    id: mention
   }]
  }, threadID), 25000)
setTimeout(() =>
api.sendMessage({
   body: "😋 "+ mentions[mention].replace("@", "") ,
   mentions: [{
    tag: mentions[mention].replace("@", ""),
    id: mention
   }]
  }, threadID), 30000)
setTimeout(() =>
api.sendMessage({
   body: "🐒"+ mentions[mention].replace("@", "") ,
   mentions: [{
    tag: mentions[mention].replace("@", ""),
    id: mention
   }]
  }, threadID), 35000)
setTimeout(() =>
api.sendMessage({
   body:"BanDar😽💋" + mentions[mention].replace("@", "") ,
   mentions: [{
    tag: mentions[mention].replace("@", ""),
    id: mention
   }]
  }, threadID), 40000)
setTimeout(() =>
api.sendMessage({
   body: "Uummaahhh ❤️❤️"+ mentions[mention].replace("@", "") ,
   mentions: [{
    tag: mentions[mention].replace("@", ""),
    id: mention
   }]
  }, threadID), 45000)
setTimeout(() =>
api.sendMessage({
   body: "IB Chal Aja Ab 💋❤️🤪"+ mentions[mention].replace("@", "") ,
   mentions: [{
    tag: mentions[mention].replace("@", ""),
    id: mention
   }]
  }, threadID), 50000)
setTimeout(() =>
api.sendMessage({
   body:"MeKo SuNai Dy Rhi Uh Ki DarKen Yahan Tk Chal JaNu umumuaahhhhh  🤪❤️💋" + mentions[mention].replace("@", "") ,
   mentions: [{
    tag: mentions[mention].replace("@", ""),
    id: mention
   }]
  }, threadID), 60000)
}
}